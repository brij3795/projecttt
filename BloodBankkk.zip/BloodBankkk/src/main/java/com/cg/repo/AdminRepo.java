package com.cg.repo;

import org.springframework.data.repository.CrudRepository;

import com.cg.entity.Admin;


public interface AdminRepo extends CrudRepository<Admin, Integer> {

}
