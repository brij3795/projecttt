package com.cg.entity;

import java.sql.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "user_infos")
public class User implements Comparable<User>{

	@Id
	@GeneratedValue
	private int id;

	private String userFirstName;

	private String userLastName;

	private Date uDOB;

	private String userEmail;

	private String userContact;

	@Column(name = "user_blood_group")
	private String userBloodGroup;

	private String userAddress;
	
	private String userPassword;
	
	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	@OneToMany
	@JoinColumn(name="patient_id")
	List<Patient> matchedpatients;

	public String getUserFirstName() {
		return userFirstName;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public List<Patient> getMatchedpatients() {
		return matchedpatients;
	}

	public void setMatchedpatients(List<Patient> matchedpatients) {
		this.matchedpatients = matchedpatients;
	}

	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}

	public String getUserLastName() {
		return userLastName;
	}

	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}



	public Date getuDOB() {
		return uDOB;
	}

	public void setuDOB(Date uDOB) {
		this.uDOB = uDOB;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserContact() {
		return userContact;
	}

	public void setUserContact(String userContact) {
		this.userContact = userContact;
	}

	public String getUserBloodGroup() {
		return userBloodGroup;
	}

	public void setUserBloodGroup(String userBloodGroup) {
		this.userBloodGroup = userBloodGroup;
	}

	public String getUserAddress() {
		return userAddress;
	}

	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}

	@Override
	public int compareTo(User o) {
		
		return this.userFirstName.compareToIgnoreCase(o.userFirstName);
	}
}
