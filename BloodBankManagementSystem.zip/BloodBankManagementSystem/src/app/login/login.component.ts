import { Component, OnInit } from '@angular/core';
import { Login } from '../model/login';
import { Router } from '@angular/router';

import { ServiceService } from "../service.service";



@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  logincheck: Login[];
  login: Login;
  admincheck: Login;
  adminEmailId: any;
  password: any;
  isLoggedin: boolean;
  status1: any;
  status2: any;
  constructor(private router: Router, private service: ServiceService) {
    this.login = new Login();
    this.adminEmailId = this.login.adminEmailId;
    this.password = this.login.password;

  }




  ngOnInit() {
    window.location.hash = "no-back-buton";
    window.location.hash = "Again-No-back-buton";
    window.onhashchange = function () {
      window.location.hash = "no-back-buton";
    }
  }
  preventBack() {
    window.history.forward();
  }


  getAdmin() {

    sessionStorage.setItem("isLoggedIn", 'true');
    sessionStorage.setItem('adminEmailId', this.adminEmailId);
    sessionStorage.setItem('password', this.password);
    console.log(sessionStorage);
    this.service.getAdmin().subscribe(res => {
      this.logincheck = res;
      this.admincheck = this.logincheck[0]


      if (this.adminEmailId === this.admincheck.adminEmailId && this.password === this.admincheck.password) {
        this.isLoggedin = true;
        // alert('login successful')
        this.router.navigate(['/admin']);
      }
      else {
        console.log('else loop')
        sessionStorage.setItem("isLoggedIn", "false");
        alert("Invalid details")


      }
    })


  }

}

