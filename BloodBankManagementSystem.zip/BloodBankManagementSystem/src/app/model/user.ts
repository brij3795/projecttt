export class User {
  matchedpatients: import("f:/BBMS6/BBMS6/src/app/model/patientdetails").Patient[];
  filter(arg0: (u: any) => boolean): User {
    throw new Error("Method not implemented.");
  }
 id: number;
 userFirstName: any;
 userLastName: any;
 userContact: any;
 userEmail: any;
 userBloodGroup: any;
 uDOB:Date;
 userAddress:any;
 userGender:any;
 userPassword:any;

}
