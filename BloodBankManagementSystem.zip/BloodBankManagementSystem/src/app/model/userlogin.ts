export class UserLogin {
    userEmail: String;
   userPassword: String;
}